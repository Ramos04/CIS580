# Demos

Each of these demos are setup like the MonoGame 3.6 Cross Platform Desktop Project template.

This means you'll *need* to have MonoGame 3.6 installed on your machine because some of the 
files are expected to be on your machine.

To run each demo in Visual Studio right click the project and select 'Set as StartUp Project'
then run it as usual.
