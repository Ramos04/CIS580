<?xml version="1.0" encoding="UTF-8"?>
<tileset name="voxelTiles_sheet" tilewidth="111" tileheight="128" spacing="1" tilecount="63" columns="9">
 <image source="voxelTiles_sheet.png" width="1024" height="1024"/>
</tileset>
