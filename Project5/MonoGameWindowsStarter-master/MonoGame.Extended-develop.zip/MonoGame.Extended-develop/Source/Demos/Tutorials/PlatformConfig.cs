﻿namespace Tutorials
{
    public class PlatformConfig
    {
        public bool IsFullScreen { get; set; } = true;
    }
}