namespace MonoGame.Extended.Gui
{
    public enum Orientation { Horizontal, Vertical }
}