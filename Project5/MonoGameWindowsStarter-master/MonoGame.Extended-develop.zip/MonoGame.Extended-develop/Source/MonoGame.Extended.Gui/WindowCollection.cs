﻿namespace MonoGame.Extended.Gui
{
    //public class WindowCollection : ElementCollection<Window, Screen>
    //{
    //    public WindowCollection(Screen parent) 
    //        : base(parent)
    //    {
    //    }
    //}
}