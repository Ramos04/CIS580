﻿namespace MonoGame.Extended.Gui
{
    //public class ScreenCollection : ElementCollection<Screen, GuiSystem>
    //{
    //    public ScreenCollection(GuiSystem parent) 
    //        : base(parent)
    //    {
    //    }
    //}
}