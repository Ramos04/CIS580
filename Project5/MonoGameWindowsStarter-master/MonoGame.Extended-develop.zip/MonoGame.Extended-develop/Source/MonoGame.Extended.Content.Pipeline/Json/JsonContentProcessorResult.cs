﻿namespace MonoGame.Extended.Content.Pipeline.Json
{
    public class JsonContentProcessorResult
    {
        public string ContentType { get; set; }
        public string Json { get; set; }
    }
}