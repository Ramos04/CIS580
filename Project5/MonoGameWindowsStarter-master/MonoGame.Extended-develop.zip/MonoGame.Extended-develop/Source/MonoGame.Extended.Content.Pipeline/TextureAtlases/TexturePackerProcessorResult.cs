﻿using MonoGame.Extended.TextureAtlases;

namespace MonoGame.Extended.Content.Pipeline.TextureAtlases
{
    public class TexturePackerProcessorResult
    {
        public TexturePackerFile Data { get; set; }
    }
}