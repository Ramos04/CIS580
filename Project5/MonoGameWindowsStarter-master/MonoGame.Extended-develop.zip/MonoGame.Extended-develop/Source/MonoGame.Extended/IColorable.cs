using Microsoft.Xna.Framework;

namespace MonoGame.Extended
{
    public interface IColorable
    {
        Color Color { get; set; }
    }
}