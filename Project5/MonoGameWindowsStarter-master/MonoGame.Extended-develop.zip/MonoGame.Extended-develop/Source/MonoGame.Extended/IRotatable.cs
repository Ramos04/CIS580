﻿namespace MonoGame.Extended
{
    public interface IRotatable
    {
        float Rotation { get; set; }
    }
}