using Microsoft.Xna.Framework;

namespace MonoGame.Extended
{
    public interface IScalable
    {
        Vector2 Scale { get; set; }
    }
}