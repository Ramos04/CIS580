﻿using Microsoft.Xna.Framework;

namespace MonoGame.Extended
{
    public interface IUpdate
    {
        void Update(GameTime gameTime);
    }
}