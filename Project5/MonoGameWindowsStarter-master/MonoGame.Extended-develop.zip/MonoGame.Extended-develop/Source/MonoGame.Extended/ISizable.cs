﻿
namespace MonoGame.Extended
{
    public interface ISizable
    {
        Size2 Size { get; set; }
    }
}