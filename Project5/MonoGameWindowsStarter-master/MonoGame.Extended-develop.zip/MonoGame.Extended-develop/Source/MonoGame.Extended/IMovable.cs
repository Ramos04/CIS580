﻿using Microsoft.Xna.Framework;

namespace MonoGame.Extended
{
    public interface IMovable
    {
        Vector2 Position { get; set; }
    }
}