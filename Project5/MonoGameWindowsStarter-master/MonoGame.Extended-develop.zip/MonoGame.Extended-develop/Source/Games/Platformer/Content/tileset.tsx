<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tileset" tilewidth="32" tileheight="32" tilecount="9" columns="3">
 <image source="tileset.png" width="96" height="96"/>
</tileset>
