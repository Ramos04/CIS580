﻿namespace Pong.GameObjects
{
    public class Paddle : GameObject
    {
    }
}