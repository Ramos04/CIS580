namespace MonoGame.Extended.Collisions
{
    public enum CollisionGridCellFlag
    {
        Empty,
        Solid,
        Interesting
    }
}