﻿namespace MonoGame.Extended.Tiled
{
    public enum TiledMapObjectDrawOrder : byte
    {
        TopDown,
        Index,
    }
}
