﻿namespace MonoGame.Extended.Tiled
{
    public enum TiledMapOrientation
    {
        Orthogonal,
        Isometric,
        Staggered
    }
}