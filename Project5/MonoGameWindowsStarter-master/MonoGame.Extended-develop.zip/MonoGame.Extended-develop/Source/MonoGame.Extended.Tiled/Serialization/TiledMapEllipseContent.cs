namespace MonoGame.Extended.Tiled.Serialization
{
    public class TiledMapEllipseContent
    {
    }
}