namespace MonoGame.Extended.Tiled
{
    public enum TiledMapTileDrawOrder : byte
    {
        RightDown,
        RightUp,
        LeftDown,
        LeftUp
    }
}