﻿using System.Collections.Generic;

namespace MonoGame.Extended.Tiled
{
    public class TiledMapProperties : Dictionary<string, string>
    {
    }
}