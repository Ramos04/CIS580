﻿namespace MonoGame.Extended.NuclexGui.Controls.Desktop
{
    /// <summary>Control for the X button in the top right corner of a window</summary>
    public class GuiCloseWindowButtonControl : GuiButtonControl
    {
    }
}