﻿using System.Collections.ObjectModel;

namespace MonoGame.Extended.SceneGraphs
{
    public class SceneEntityCollection : Collection<SceneEntity>
    {
    }
}