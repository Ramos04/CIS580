
## Tweening
The `MonoGame.Extended.Tweening` library contains class extensions for tween based animations.
