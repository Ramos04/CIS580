
## Gui
The `MonoGame.Extended.Gui` library contains a complete GUI system.  It includes Buttons, Text Boxes, Dialogs and many other controls, and is skinnable.

## NuclexGui
The `MonoGame.Extended.NuclexGui` library contains an implementation of the [Nuclex GUI Framework](https://nuclexframework.codeplex.com/wikipage?title=Nuclex.UserInterface) for XNA, ported to MonoGame.