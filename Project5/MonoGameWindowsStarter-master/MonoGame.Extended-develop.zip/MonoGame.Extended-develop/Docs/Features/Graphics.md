## Graphics
The `MonoGame.Extended.Graphics` library contains extensions useful for generating dynamic geometry and batching draw calls.