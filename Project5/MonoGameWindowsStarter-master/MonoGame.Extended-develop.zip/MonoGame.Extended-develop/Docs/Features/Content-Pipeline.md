
## Content.Pipeline
The `MonoGame.Extended.Content.Pipeline` library extends the [MonoGame Content Pipeline tool](http://www.monogame.net/documentation/?page=Pipeline). This adds Animations, BitmapFonts, TextureAtlases, and Tiled maps to the Content Pipeline tool.