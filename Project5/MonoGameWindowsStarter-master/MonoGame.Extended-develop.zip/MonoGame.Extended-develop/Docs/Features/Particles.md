## Particles
The `MonoGame.Extended.Particles` library contains a high performance Particle System ported from the [Mercury Particle Engine](matthew-davey.github.io/mercury-particle-engine/).
