
## SceneGraphs
The `MonoGame.Extended.SceneGraphs` library contains a scene graph (tree) system.