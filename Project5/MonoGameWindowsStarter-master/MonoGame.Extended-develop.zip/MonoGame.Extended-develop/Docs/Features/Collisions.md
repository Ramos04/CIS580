
## Collisions
The `MonoGame.Extended.Collisions` library contains a 2D grid based collision system.