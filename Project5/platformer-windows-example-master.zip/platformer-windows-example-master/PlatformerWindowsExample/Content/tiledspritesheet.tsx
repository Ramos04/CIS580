<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.2" name="spritesheet" tilewidth="21" tileheight="21" spacing="2" margin="2" tilecount="480" columns="30">
 <image source="spritesheet.png" trans="5e81a2" width="694" height="372"/>
</tileset>
